<?php
    require_once 'controller/loginContr.php';
    require_once ("controller/cookieContr.php");
    compCookieIndex();
?>