<?php
require_once ("cookieContr.php");
    deleteCookie();
?>